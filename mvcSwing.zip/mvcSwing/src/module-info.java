/**
 * 
 */
/**
 * 
 */
module mvcSwing {
	requires java.desktop;
	requires java.sql;
}